import{U as r}from"./UserPreview-B_acB7AM.js";import{j as o}from"./index-BCfowrqk.js";const n=e=>o(r,{elementId:"personalWorkspace",rounded:!1,...e});export{n as P};
