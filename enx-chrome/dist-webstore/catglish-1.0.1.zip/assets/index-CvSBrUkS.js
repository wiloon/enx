const E="enx-pending-sentence",e="enx-latest-page-word";export{e as L,E as P};
