import{i as t}from"./index-BCfowrqk.js";const i=({routing:r,path:n})=>n&&!r?{routing:"path",path:n}:r!=="path"&&n?t(r):{routing:r,path:n};export{i as n};
